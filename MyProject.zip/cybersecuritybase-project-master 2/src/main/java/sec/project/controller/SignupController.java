package sec.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import sec.project.domain.Signup;
import org.springframework.web.bind.annotation.PathVariable;
import sec.project.repository.SignupRepository;
import org.springframework.ui.Model;

@Controller
public class SignupController {

    @Autowired
    private SignupRepository signupRepository;
   // private AccountRepository accountRepository;

    @RequestMapping("*")
    public String defaultMapping() {
        return "redirect:/form";
    }
   
    @RequestMapping(value = "/password", method = RequestMethod.GET)
    public String changepw() {
        return "password";
    }
    
    @RequestMapping(value = "/form", method = RequestMethod.GET)
    public String loadForm() {
        return "form";
    }
    
  
    @RequestMapping(value="/admin", method=RequestMethod.GET )
    public String list(Model model) {
        
       model.addAttribute("list", signupRepository.findAll());
        return "admin";
    }  
   
       
   @RequestMapping(value="/check/{id}", method=RequestMethod.POST )
   public String updatePayment(@PathVariable ("id") long id, Signup signup, Model model) { 
     Signup post;
     post  = signupRepository.findOne(id);
     post.setStatus("Paid");
     model.addAttribute("list", signupRepository.save(post));
     return "check";        
     }       
         
 @RequestMapping(value="/check/{id}", method=RequestMethod.GET )
 public String updatePayment(@PathVariable ("id") long id, Model model) { 
     model.addAttribute("list", signupRepository.findOne(id));
       return "check";  
   
   }     
  
   
  @RequestMapping(value = "/form", method = RequestMethod.POST)
   public String submitForm(@RequestParam Long id, @RequestParam String name, @RequestParam String address, @RequestParam String accountnr, @RequestParam String status) {
       
       signupRepository.save(new Signup(id, name, address, accountnr, status));
        return "done";
  
    }

}
