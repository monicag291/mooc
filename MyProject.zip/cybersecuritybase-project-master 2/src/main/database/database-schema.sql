/* Do not change this schema */
DROP TABLE IF EXISTS REG;
CREATE TABLE REG (
    id varchar(9) PRIMARY KEY,
    name varchar(200), address varchar(200), accountnr varchar(200), status varchar(200));
