INSERT INTO REG (id, name, address, accountnr, status) VALUES ('', 'Ted', 'Helsinki','FI0012341234123412340000','Y');

